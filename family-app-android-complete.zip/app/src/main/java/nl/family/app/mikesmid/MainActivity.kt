package nl.family.app.mikesmid

import android.content.Intent
import android.os.Bundle
import android.webkit.*
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {

  private lateinit var webView: WebView

  // Your inputs normalized:
  private val fallbackUrl = "https://mikesmid.nl/paneel"
  private val configUrl = "https://mikesmid.nl/paneel/app-config.json"

  private val prefs by lazy { getSharedPreferences("family_app_prefs", MODE_PRIVATE) }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_main)

    webView = findViewById(R.id.webView)
    setupWebView()

    // Load cached URL first (fast startup), else fallback
    val cachedStart = prefs.getString("cached_start_url", null)
    webView.loadUrl(cachedStart ?: fallbackUrl)

    // Fetch remote config and update
    CoroutineScope(Dispatchers.Main).launch {
      val cfg = withContext(Dispatchers.IO) { fetchConfigSafely(configUrl) }
      cfg?.let { applyConfig(it) }
    }

    // Android back button: go back in WebView if possible
    onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
      override fun handleOnBackPressed() {
        if (webView.canGoBack()) webView.goBack() else finish()
      }
    })
  }

  private fun setupWebView() {
    val ws = webView.settings
    ws.javaScriptEnabled = true
    ws.domStorageEnabled = true
    ws.databaseEnabled = true
    ws.loadsImagesAutomatically = true
    ws.useWideViewPort = true
    ws.loadWithOverviewMode = true
    ws.mediaPlaybackRequiresUserGesture = false

    CookieManager.getInstance().setAcceptCookie(true)
    CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

    webView.webChromeClient = WebChromeClient()

    webView.webViewClient = object : WebViewClient() {

      override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
        val uri = request.url ?: return false

        val allowList = prefs.getStringSet("allow_list", setOf("mikesmid.nl")) ?: setOf("mikesmid.nl")
        val host = (uri.host ?: "").lowercase()

        val isAllowed = allowList.any { allowed ->
          val a = allowed.lowercase()
          host == a || host.endsWith("." + a)
        }

        return if (isAllowed) {
          false
        } else {
          startActivity(Intent(Intent.ACTION_VIEW, uri))
          true
        }
      }

      override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
        // Do not bypass SSL errors
        handler.cancel()
      }
    }
  }

  private fun applyConfig(cfg: RemoteConfig) {
    prefs.edit().putStringSet("allow_list", cfg.allowList.toSet()).apply()

    val start = cfg.startUrl.ifBlank { fallbackUrl }
    prefs.edit().putString("cached_start_url", start).apply()

    val current = webView.url ?: ""
    if (!urlsEquivalent(current, start)) {
      webView.loadUrl(start)
    }
  }

  private fun urlsEquivalent(a: String, b: String): Boolean {
    fun norm(s: String) = s.trim().trimEnd('/')
    return norm(a) == norm(b)
  }

  data class RemoteConfig(
    val startUrl: String,
    val allowList: List<String>
  )

  private fun fetchConfigSafely(url: String): RemoteConfig? {
    return try {
      val conn = (URL(url).openConnection() as HttpURLConnection).apply {
        requestMethod = "GET"
        connectTimeout = 7000
        readTimeout = 7000
        setRequestProperty("Accept", "application/json")
      }

      conn.inputStream.bufferedReader().use { reader ->
        val body = reader.readText()
        val json = JSONObject(body)

        val startUrl = json.optString("startUrl", fallbackUrl)

        val allowArr = json.optJSONArray("allowList")
        val allowList = mutableListOf<String>()
        if (allowArr != null) {
          for (i in 0 until allowArr.length()) {
            val v = allowArr.optString(i).trim()
            if (v.isNotEmpty()) allowList.add(v)
          }
        }
        if (allowList.isEmpty()) allowList.add("mikesmid.nl")

        RemoteConfig(startUrl = startUrl, allowList = allowList)
      }
    } catch (_: Exception) {
      null
    }
  }
}
